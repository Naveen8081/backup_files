#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include"contact.h"
#include <stdio_ext.h>

extern int countnmsrch;

// Checks if the input name contain only alphabetics
int is_validname(char* name)
{
	int i=0;
	while(name[i])
	{
		if(!( (isalpha((unsigned char)name[i])) || (name[i]==' ') ))
		{
			printf("Invalid Name!\n");
			return 0;
		}
		i++;
	}
	return 1;
}

// Checks if the input phone contain only 10 digits
int is_validphone(char* phone)
{
	int i=0;
	if(strlen(phone)!=10)
	{
		printf("Invalid Phone!\n");
		return 0;
	}

	while(phone[i])
	{
		if( !isdigit(phone[i]) )
		{
			printf("Invalid Phone!\n");
			return 0;
		}
		i++;
	}
	return 1;
}

// Checks if the input email contain a '@' ,'.com' and alphabetic character before them
int is_validemail(char* email)
{
	int i=0;
	int spclchr=0;
	while(email[i])
	{
		if( !(isalnum(email[i])) )
		{
			if(!(email[i]=='@' || email[i] =='.') || (++spclchr)>2)
			{
				printf("Invalid Email!\n");
				return 0;
			}
		}
		i++;			
	}


	char* ind1;
	char* ind2;
	ind1=strchr(email,'@');
	if(ind1)
	{
		if(isalnum(*(ind1-1)) && isalnum(*(ind1+1)))
		{
			ind2=strstr(email,".com");
			if(ind2 > ind1)
			{     
				if(isalpha(*(--ind2)))
					return 1;
			}
		}
	}
	printf("Invalid Email!\n");
	return 0;
}

// Checks index of existance of name and return index+1 also return 0 if name not found
int is_nameexist(char* name,AddressBook *addressBook)
{	
	int index;	
	int count=0;
	for(int i=0; i<addressBook->contactCount; i++)
	{
		if(!strcmp(addressBook->contacts[i].name,name))
		{
			if(count==0)
			{
				titleprompt();			
			}
			count++;
			printindex(i, addressBook);
			index=i;
		}
	}
	countnmsrch=count;	

	if(!count)
	{
		printf("\nContact with entered name not found!\n");
		return 0;
	}
	else
		return index+1;

}

// Checks index of existance of phone and return index+1 also return 0 if phone not found
int is_phexist(char* str,AddressBook *addressBook)
{
	int i;
	for(i=0;i<addressBook->contactCount;i++)
	{
		if(!strcmp(addressBook->contacts[i].phone,str))
			return i+1;
	}
	return 0;	
}

// Checks index of existance of email and return index+1 also return 0 if email not found
int is_mailexist(char* str,AddressBook *addressBook)
{
	int i;
	for(i=0;i<addressBook->contactCount;i++)
	{
		if(!strcmp(addressBook->contacts[i].email,str))
			return i+1;
	}
	return 0;    
}

// Ask entity to research if multiple contact found in same name and return researched address
int research(AddressBook *addressBook)
{
	int researchindex;
	char entity[20];
	int choice;
	do
	{
		printf("\nMultiple contact matching with entered name!\nEnter entity to select from contacts\n");
		printf("1.Phone\t2.Email\n");
		scanf("%d",&choice);
		__fpurge(stdin);
	}while((!(choice==1 || choice==2)) && printf("Invalid choice\n"));

	int temp=0;
	if(choice==1)
	{
		do
		{
			printf("Enter phone:\n");
			scanf("%s",entity);
		}while(! ((( temp=is_validphone(entity) && (researchindex=is_phexist(entity,addressBook)) )) || (!temp || printf("Invalid Entry!\n"))) );

		printf("Contact selected:\n");
		titleprompt();
		printindex(researchindex-1,addressBook);
	}

	if(choice==2)
	{
		do
		{
			printf("Enter email:\n");
			scanf("%s",entity);
		}while(! ((( temp=is_validemail(entity) && (researchindex=is_mailexist(entity,addressBook)) )) || (!temp ||  printf("Invalid Entry!\n"))) );

		printf("Contact selected:\n");
		titleprompt();
		printindex(researchindex-1,addressBook);
	}
	return researchindex;
}



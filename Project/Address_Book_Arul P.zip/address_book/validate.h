#include<stdio.h>
#include<ctype.h>


int is_validname(char* );
int is_validphone(char* );
int is_validemail(char* );
int is_phexist(char* ,AddressBook *);
int is_mailexist(char*,AddressBook *);
int is_nameexist(char*,AddressBook *);
int research(AddressBook *);

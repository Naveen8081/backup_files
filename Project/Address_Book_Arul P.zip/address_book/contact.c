#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio_ext.h>
#include "contact.h"
#include "file.h"
#include "validate.h"

int countnmsrch;

void titleprompt()
{
	printf("----------------------------------------------------------------------");
	printf("\n%-20s %-20s %-20s\n","NAME", "PHONE", "EMAIL");
	printf("----------------------------------------------------------------------\n");
}


void printindex(int index, AddressBook *addressBook)
{
	printf("%-20s %-20s %-20s\n",addressBook->contacts[index].name, addressBook->contacts[index].phone, addressBook->contacts[index].email);
}

void listContacts(AddressBook *addressBook) 
{
	titleprompt();

	//Print Contact from 0 to contactCount from struct array
	for(int i=0;i<addressBook->contactCount;i++)
	{
		printindex(i,addressBook);
	}    
}

void initialize(AddressBook *addressBook) {
	addressBook->contactCount = 0;

	// Load contacts from file during initialization (After files)
	loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
	saveContactsToFile(addressBook); // Save contacts to file
	exit(EXIT_SUCCESS); // Exit the program
}

void createContact(AddressBook *addressBook)
{
	do
	{
		printf("Enter Name:\n");
		scanf("%[^\n]",addressBook->contacts[addressBook->contactCount].name);
		getchar();
	}while(!is_validname(addressBook->contacts[addressBook->contactCount].name));

	do
	{
		printf("Enter Number:\n");
		scanf("%s",addressBook->contacts[addressBook->contactCount].phone);
	}while(!is_validphone(addressBook->contacts[addressBook->contactCount].phone) ||(is_phexist(addressBook->contacts[addressBook->contactCount].phone,addressBook)&& printf("Phone Number Exist!\n"))); // Print invalid or pre-existing prompt based on return value from is_validphone and is_phexist fn

	do
	{
		printf("Enter Email:\n");
		scanf("%s",addressBook->contacts[addressBook->contactCount].email);
	}while(!is_validemail(addressBook->contacts[addressBook->contactCount].email) ||(is_mailexist(addressBook->contacts[addressBook->contactCount].email,addressBook)&& printf("Email Exist!\n")) ); // Print invalid or pre-existing prompt based on return value from is_validemail & is_mailexist fn


	addressBook->contactCount++;	
	printf("Contact added successfully!\n");
}

int searchContact(AddressBook *addressBook) 
{
	int index;
	char entity[20];
	int entity_choice;

	// Prompt the user to enter the entity the user want to search
	do
	{
		printf("\nSelect entity to search:\n1.Name\t2.Phone\t3.Email\n");
		scanf("%d",&entity_choice);
		__fpurge(stdin);
	}while((!entity_choice>=1 && entity_choice<=3) && printf("Invalid choice!\n"));	

	countnmsrch=0;
	if(entity_choice==1)
	{
		do
		{
			printf("Enter Name:\n");
			scanf("%[^\n]",entity);
		}while(!is_validname(entity));		// Flow enter into loop if name is not valid

		index=is_nameexist(entity,addressBook);		// is_nameexist returns the index(+1) where the matching contact found 

		return index;
	}

	if(entity_choice==2)
	{
		do
		{
			printf("Enter Phone:\n");
			scanf("%s",entity);
		}while(!is_validphone(entity));		// Flow enter into loop if phone is not valid

		int index=is_phexist(entity,addressBook);	// is_phexist returns the index(+1) where the matching contact found
		if(index)
		{	
			titleprompt();
			printindex(index-1,addressBook);
		}
		else
			printf("Contact matching this phone not found!\n");			

		return index;
	}

	if(entity_choice==3)
	{
		do
                {
                        printf("Enter Email:\n");
                        scanf("%s",entity);
                }while(!is_validemail(entity));		// Flow enter into loop if email is not valid
		
		int index=is_mailexist(entity,addressBook);	// is_mailexist returns the index(+1) where the matching contact found
		if(index)
		{
			titleprompt();
			printindex(index-1,addressBook);
		}
		else
			printf("Contact matching this email not found!\n");   

		return index;
	}
}

void editContact(AddressBook *addressBook)
{
	int index=searchContact(addressBook);		//searchContact returns index(+1) where the contact is found also 0 when contact not found
	if(!index)
		return;		// Terminate editContact fn if contact is not found while searching
	if(countnmsrch >1)
	{
		index=research(addressBook);		// research fn is called when multiple contacts found with same name
	}

	char entity[20];
	int choice;
	do
	{
		printf("\nSelect entity to Edit:\n1.Name\t2.Phone\t3.Email\n");
		scanf("%d",&choice);
		__fpurge(stdin);
	}while((!choice>=1 && choice<=3) && printf("Invalid choice!\n"));

	if(choice==1)
	{
		do
		{
			printf("Enter Name:\n");
			scanf("%[^\n]",entity);
		}while(!is_validname(entity));
		strcpy(addressBook->contacts[index-1].name,entity);	 	//input entity copied to contacts after validation 
	}

	if(choice==2)
	{
		do
		{
			printf("Enter Phone:\n");
			scanf("%s",entity);
		}while(!is_validphone(entity) ||(is_phexist(entity,addressBook)&& printf("Phone number exist!\n")));
		strcpy(addressBook->contacts[index-1].phone,entity);		//input entity copied to contacts after validation 
	}

	if(choice==3)
	{
		do
		{
			printf("Enter Email:\n");
			scanf("%s",entity);
		}while(!is_validemail(entity) ||(is_mailexist(entity,addressBook)&& printf("Email already exist!\n")));
		strcpy(addressBook->contacts[index-1].email,entity);		// input entity copied to contacts after validation 
	}
	printf("Contact Updated Successfully!\n");
}

void deleteContact(AddressBook *addressBook)
{
	int index=searchContact(addressBook);
	if(!index)
		return;

	if(countnmsrch >1)
	{
		index=research(addressBook);
	}

	if(!(index==addressBook->contactCount))		// shift i+1 (th) data to i (if searched contact is not last one)
	{
		for(int i=index-1; i< (addressBook->contactCount-1); i++)	
		{
			strcpy(addressBook->contacts[i].name, addressBook->contacts[i+1].name);
			strcpy(addressBook->contacts[i].phone, addressBook->contacts[i+1].phone);
			strcpy(addressBook->contacts[i].email, addressBook->contacts[i+1].email);
		}
	}
	addressBook->contactCount--;	// Decrement contactCount after shiting, if searched contact is last contact shifting wont happen (only decrement)
	printf("\nContact deleted successfully!\n");
}

